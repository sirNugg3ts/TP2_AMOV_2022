package com.example.cantina_isec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
